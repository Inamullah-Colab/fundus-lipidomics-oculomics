import pandas as pd
import numpy as np
import pingouin as pg
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from statsmodels.stats.multitest import multipletests

# -----------------------------
# STEP 1: Partial Correlation
# -----------------------------
def run_partial_corr(df_fundus, df_lipid):
    for df in [df_fundus, df_lipid]:
        if 'sex' in df.columns and df['sex'].dtype == object:
            df['sex'] = df['sex'].astype('category').cat.codes
    df = pd.merge(df_fundus, df_lipid, on='participant_id', suffixes=('_fundus', '_lipid'))
    df['age'] = df['age_fundus']
    df['sex'] = df['sex_fundus']
    df.drop(columns=['age_fundus', 'sex_fundus', 'age_lipid', 'sex_lipid'], inplace=True)
    fundus_features = [c for c in df_fundus.columns if c not in ['participant_id', 'age', 'sex']]
    lipid_features = [c for c in df_lipid.columns if c not in ['participant_id', 'age', 'sex']]
    results = []
    for f in fundus_features:
        for l in lipid_features:
            sub = df[['age', 'sex', f, l]].dropna()
            if len(sub) < 20:
                continue
            res = pg.partial_corr(data=sub, x=f, y=l, covar=['age', 'sex'], method='pearson')
            results.append({
                'fundus_feature': f, 'lipid_feature': l,
                'r': res['r'].values[0], 'p_value': res['p-val'].values[0],
                'CI_lower': res['CI95%'].iloc[0][0],
                'CI_upper': res['CI95%'].iloc[0][1], 'n': len(sub)
            })
    df_res = pd.DataFrame(results)
    df_res['p_fdr'] = multipletests(df_res['p_value'], method='fdr_bh')[1]
    df_res['significant_fdr'] = df_res['p_fdr'] < 0.05
    return df_res

# -----------------------------
# STEP 2: Bubble Plot
# -----------------------------
def plot_bubble(df, selected_fundus, output_path):
    df_sel = df[df['fundus_feature'].isin(selected_fundus)].copy()
    lipid_max_abs_r = df_sel.groupby('lipid_feature')['r'].apply(lambda x: abs(x).max())
    top30_lipids = list(lipid_max_abs_r.sort_values(ascending=False).head(30).index)
    df_top30 = df_sel[df_sel['lipid_feature'].isin(top30_lipids)].copy()

    y_map = {f: i for i, f in enumerate(df_top30['fundus_feature'].unique())}
    df_top30['y'] = df_top30['fundus_feature'].map(y_map)

    palette = sns.color_palette("tab20", len(top30_lipids))
    color_dict = dict(zip(top30_lipids, palette))
    df_top30['color'] = df_top30['lipid_feature'].map(color_dict)

    plt.figure(figsize=(14, 10))
    plt.scatter(df_top30['r'], df_top30['y'], s=df_top30['r'].abs() * 1000,
                c=df_top30['color'], alpha=0.9, edgecolors='black')

    sig_rows = df_top30[df_top30['significant_fdr']].copy()
    for _, row in sig_rows.iterrows():
        plt.text(row['r'], row['y'] + 0.20, '*', color='red', fontsize=16,
                 ha='center', va='bottom')

    plt.yticks(list(y_map.values()), list(y_map.keys()))
    plt.axvline(0, color='gray', linestyle='--')
    plt.xlabel('Partial Correlation (r)')
    plt.title('Bubble Plot of Top 30 Lipid Features vs Fundus Features (FDR < 0.05)')

    handles = [plt.Line2D([0], [0], marker='o', label=lipid,
                          color='w', markerfacecolor=color_dict[lipid], markersize=9) for lipid in top30_lipids]
    plt.legend(handles=handles, bbox_to_anchor=(1.05, 1), loc='upper left', title='Lipid Feature')
    plt.tight_layout()
    plt.savefig(output_path.replace('.png', '.pdf'))
    plt.savefig(output_path, dpi=600)
    plt.close()
    return color_dict, top30_lipids

# -----------------------------
# STEP 3: Individual Network Graphs
# -----------------------------
def plot_individual_networks(df, selected_fundus, color_dict, output_prefix):
    df_net = df[(df['fundus_feature'].isin(selected_fundus)) & df['significant_fdr']]
    hub_counts = df_net.groupby('fundus_feature')['lipid_feature'].nunique()
    hub_fundus = hub_counts[hub_counts > 5].index.tolist()

    for f in hub_fundus:
        sub = df_net[df_net['fundus_feature'] == f]
        G = nx.Graph()
        for _, row in sub.iterrows():
            G.add_edge(f, row['lipid_feature'], weight=abs(row['r']), r=row['r'], label='*')

        pos = nx.spring_layout(G, seed=42)
        node_colors = ['gray' if n == f else color_dict.get(n, 'lightgray') for n in G.nodes()]
        node_sizes = [1200 if n == f else 900 for n in G.nodes()]
        edge_colors = ['blue' if d['r'] > 0 else 'red' for _, _, d in G.edges(data=True)]
        edge_widths = [d['weight'] * 4 for _, _, d in G.edges(data=True)]

        plt.figure(figsize=(9, 6))
        nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=node_sizes)
        nx.draw_networkx_edges(G, pos, edge_color=edge_colors, width=edge_widths, alpha=0.8)
        nx.draw_networkx_labels(G, pos, font_size=9)
        labels = {(u, v): d['label'] for u, v, d in G.edges(data=True)}
        nx.draw_networkx_edge_labels(G, pos, edge_labels=labels, font_size=10)

        plt.title(f"{f} (FDR<0.05, >5 lipids)")
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(f"{output_prefix}_{f}.pdf")
        plt.savefig(f"{output_prefix}_{f}.png", dpi=600)
        plt.close()

# -----------------------------
# STEP 4: Forest Plot
# -----------------------------
def plot_forest(df, output_path, color_dict=None):
    df_sig = df[df['significant_fdr']]
    df_sig = df_sig[df_sig['fundus_feature'] != 'average_width']
    df_top = df_sig.reindex(df_sig['r'].abs().sort_values(ascending=False).index).head(20).copy()
    df_top.reset_index(drop=True, inplace=True)
    df_top['label'] = df_top['fundus_feature'] + ' vs ' + df_top['lipid_feature']
    df_top['r_label'] = (
        'r=' + df_top['r'].round(2).astype(str) +
        ' [' + df_top['CI_lower'].round(2).astype(str) +
        ', ' + df_top['CI_upper'].round(2).astype(str) + ']'
    )

    fig, ax = plt.subplots(figsize=(11, 8))
    y_pos = np.arange(len(df_top))

    ax.errorbar(df_top['r'], y_pos,
                xerr=[df_top['r'] - df_top['CI_lower'], df_top['CI_upper'] - df_top['r']],
                fmt='o', color='black', ecolor='blue', capsize=4, markersize=6, markerfacecolor='white')

    for i, row in df_top.iterrows():
        ax.plot(row['r'], y_pos[i], 'o', markersize=7,
                color=color_dict.get(row['lipid_feature'], 'black'),
                markeredgecolor='black', zorder=3)

        ax.text(row['r'], y_pos[i] + 0.35, row['r_label'], fontsize=8,
                ha='center', va='bottom',
                bbox=dict(facecolor='white', edgecolor='gray', boxstyle='round,pad=0.3', alpha=0.8))

    ax.set_yticks(y_pos)
    ax.set_yticklabels(df_top['label'])
    ax.axvline(0, linestyle='--', color='gray')
    ax.set_xlabel("Partial Correlation (r)")
    ax.set_title("Top 20 Fundus–Lipid Associations (FDR < 0.05)")
    plt.tight_layout()
    plt.savefig(output_path.replace('.png', '.pdf'))
    plt.savefig(output_path, dpi=600)
    plt.close()

# -----------------------------
# Main Execution
# -----------------------------
df_fundus = pd.read_csv("fundus_avg.csv")
df_lipid = pd.read_csv("lipids_age.csv")
selected_fundus = [
    'vein_fractal_dimension', 'vein_vessel_density', 'fractal_dimension',
    'vein_average_width', 'artery_fractal_dimension', 'vessel_density',
    'artery_vessel_density', 'artery_distance_tortuosity', 'artery_tortuosity_density',
    'artery_average_width'
]

results_df = run_partial_corr(df_fundus, df_lipid)
color_dict, top30_lipids = plot_bubble(results_df, selected_fundus, "bubble_plot_top30.png")
plot_individual_networks(results_df, selected_fundus, color_dict, "network_graph")
plot_forest(results_df, "forest_plot_top20.png", color_dict=color_dict)
