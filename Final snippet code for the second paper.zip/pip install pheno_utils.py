pip install pheno_utils
from pheno_utils import PhenoLoader
pl = PhenoLoader('fundus')
pl
#this will display (76 fields) three tables ['fundus', microvasculature', 'age_sex']
#data dictinoary
pl.dict.head()
#for showing all fields
pl[pl.fields].head(3)
df = pl[pl.fields]
df.to_csv('full_fundus.csv')
df1 = pd.read_csv('full_fundus.csv')
df1
df1.columns.to_list()
#this will shows the head of the columns list 
#so then drop the irrelevant cols name
drops_cols = ['cohort','reserach_stage'...........]
df1 =df1.drop(columns=drops_cols)
df1
import pandas as pd

# 1) Read the CSV into df2 (make sure to spell read_csv correctly!)
df2 = pd.read_csv("fundus_age.csv")  
#     ^^^ If you wrote "pd.read csv" or "pd.readCsv", Python will throw a NameError here 
#     because pd.read_csv never actually ran and df2 was never created.

# 2) Find all columns whose names end with '_left'
left_cols = [col for col in df2.columns if col.endswith("_left")]

# 3) Loop through each '_left' column and average with its '_right' partner
for left in left_cols:
    base_name = left[:-5]          # strip off the '_left' suffix
    right = base_name + "_right"   # the matching '_right' column
    
    if right in df2.columns:
        # ALWAYS put parentheses around the sum, otherwise you'll do left + (right/2)
        df2[base_name] = (df2[left] + df2[right]) / 2

# 4) Drop all original '_left' and '_right' columns
cols_to_drop = [c for c in df2.columns 
                if c.endswith("_left") or c.endswith("_right")]
df2_reduced = df2.drop(columns=cols_to_drop)

# 5) Save the reduced DataFrame
df2_reduced.to_csv("fundus_avg.csv", index=False)
